

    <div class="form-group">
            <label  class="col-sm-2 control-label">Type Name</label>

            <div class="col-sm-6">

      <input type="text" class="form-control" name="type_name" placeholder="Name" value="<?php if(isset($type->type_name )) : echo $type->type_name ;endif ?>">
            </div>
        </div>



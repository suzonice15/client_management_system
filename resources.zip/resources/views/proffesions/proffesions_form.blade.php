

    <div class="form-group">
            <label  class="col-sm-2 control-label">Proffesion Name</label>

            <div class="col-sm-6">

      <input type="text" class="form-control" name="profession_name" placeholder="Name" value="<?php if(isset($profession->profession_name )) : echo $profession->profession_name ;endif ?>">
            </div>
        </div>





    <div class="form-group">
            <label  class="col-sm-2 control-label">Position Name</label>

            <div class="col-sm-6">

      <input type="text" class="form-control" name="position_name" id="position_name" placeholder="Name" value="<?php if(isset($position->position_name )) : echo $position->position_name ;endif ?>">
            </div>

        </div>


    <span id="error_position"></span>

<ul>
<li><a href="buy-online"><span class="fa fa-shopping-cart"> Buy Online</span></a></li>
<li><a href="emi"><span class="fa fa-credit-card"> EMI</span></a></li>
<li><a title="bKash" href="#"><span class="fa fa-phone"> +8801837441061</span></a></li>
<li><a title="Whatsapp" href="#"><span class="fa fa-phone"> +8801837441062</span></a></li>
<li><a style="width: 197px;" href="mailto: jncomputerbd1@gmail.com"><span class="fa fa-envelope"> jncomputerbd1@gmail.com</span></a></li>
<li><a href="https://bit.ly/2HaYdVD"><span class="fa fa-fw fa-map-marker"> Location</span></a></li>
</ul>
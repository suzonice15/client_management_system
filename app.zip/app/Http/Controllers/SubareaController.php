<?php

namespace App\Http\Controllers;

use App\subarea;
use Illuminate\Http\Request;

class SubareaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\subarea  $subarea
     * @return \Illuminate\Http\Response
     */
    public function show(subarea $subarea)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\subarea  $subarea
     * @return \Illuminate\Http\Response
     */
    public function edit(subarea $subarea)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\subarea  $subarea
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, subarea $subarea)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\subarea  $subarea
     * @return \Illuminate\Http\Response
     */
    public function destroy(subarea $subarea)
    {
        //
    }
}
